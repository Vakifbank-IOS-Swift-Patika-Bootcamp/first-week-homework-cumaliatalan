import UIKit
/* 1- Palindrome. Verilen Stringin palindrome
 olup olmadığını kontrol eden bir fonksiyon yazınız.
*/

func isPalindrome(thisString : String) -> Bool {
    
    let reverseString = String(thisString.reversed()) // gelen string ters cevrilir.
    
    if (thisString == reverseString) { // eger ters ve duz hali ayni ise
        return true // true doner
    } else {
        return false 
    }
}

print(isPalindrome(thisString: "madam"))
