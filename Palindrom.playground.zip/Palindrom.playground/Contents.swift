import UIKit
/* 1- Palindrome. Verilen Stringin palindrome
 olup olmadığını kontrol eden bir fonksiyon yazınız.
*/



func isPalindrome(thisString : String) -> Bool {
    
    var string = String(thisString
        .replacingOccurrences(of: " ", with: "") // thisString icinde bosluk varsa sileriz.
        .lowercased() // tüm karakterleri kucuk harfe donustururuz.
        )

    let reverseString = String(string.reversed()) // gelen string ters cevrilir.
    
    if (string == reverseString) { // eger ters ve duz hali ayni ise
        return true // true doner
    } else {
        return false 
    }
}

print(isPalindrome(thisString: "MaDam madam"))
