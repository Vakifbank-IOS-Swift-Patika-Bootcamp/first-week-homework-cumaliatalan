import UIKit

/*
 Verilen bir array içerisindeki her bir elemanın sayısını veren bir fonksiyon yazınız.
 */

// generics ile çözecen

let array = [true, true, false, true] // istediginiz tipte array verebilirsiniz buraya.

//Iki tipte func yazdim. over islemi ile gereken func'a girecektir.

func frequence(arr : Array<Int>) {
    let mappedItems = arr.map { ($0, 1) } // array'i mapliyoruz. benzersiz elemanlara sahip olmasi icin.
    let counts = Dictionary(mappedItems, uniquingKeysWith: +) // benzeri bulunan her key elemanin value degerine bir eklenir
    print(counts) //counts bir dict sinifidir. key:value olarak yapilan islemi yazdirir.
}

func frequence(arr : Array<String>) {
    let mappedItems = arr.map { ($0, 1) } // array'i mapliyoruz. benzersiz elemanlara sahip olmasi icin.
    let counts = Dictionary(mappedItems, uniquingKeysWith: +) // benzeri bulunan her key elemanin value degerine bir eklenir
    print(counts) //counts bir dict sinifidir. key:value olarak yapilan islemi yazdirir.
}

func frequence(arr : Array<Bool>) {
    let mappedItems = arr.map { ($0, 1) } // array'i mapliyoruz. benzersiz elemanlara sahip olmasi icin.
    let counts = Dictionary(mappedItems, uniquingKeysWith: +) // benzeri bulunan her key elemanin value degerine bir eklenir
    print(counts) //counts bir dict sinifidir. key:value olarak yapilan islemi yazdirir.

}

frequence(arr: array)
