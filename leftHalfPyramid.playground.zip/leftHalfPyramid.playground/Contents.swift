import UIKit
/*
*
**
***
 */
func starPatternLeft(row : Int) {
    
    for i in 1..<row { // verilen satir degerine gore
        for _ in 1...i { // her satirda i degeri kadar * yazilir.
            print("*", terminator: "")
        }
        print("") //satir arasi deger.
    }
}

starPatternLeft(row: 5)
