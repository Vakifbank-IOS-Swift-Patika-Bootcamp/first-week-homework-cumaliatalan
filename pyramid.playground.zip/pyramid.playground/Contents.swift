import UIKit

func piramidPattern(row : Int) {

    for i in 1..<row{ // satir degeri kadar
        for _ in 1...row-i{ // row - i kadar bosluk yazar
            print(terminator:" ")
        }
        for _ in 1...i{ // i degeri kadar * karakterini yazar
            print("*" ,terminator:" ") // her * arasina bir de bosluk koyar.
        }
        print("") // satirlar arasi 
    }
}

piramidPattern(row: 7)
