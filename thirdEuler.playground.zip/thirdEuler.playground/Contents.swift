import UIKit

/*
 The prime factors of 13195 are 5, 7, 13 and 29.

 What is the largest prime factor of the number 600851475143 ?
 */

/*
 13195'in asal çarpanları 5, 7, 13 ve 29'dur.

 600851475143 sayısının en büyük asal çarpanı kaçtır?
 */

func largestPrimeFactor(number : Int) -> Int {
    
    var num = number //number let oldugu icin degistiremiyor. dolayisiyla number degerini var degiskene atadim.
    var primeFactor = 2
    
    while num > 1 {
        if num % primeFactor == 0 { //number'in primeFactor modu 0 ise
            num /= primeFactor // primeFactor'e bolunur. Cunku icindeki tüm primeFactorlerden arindirilmali
        } else { //primeFactor'e tam bolunmezse yeni primeFactor icin artirma islemi yapilir.
            primeFactor += 1
        }
    }
    
    return primeFactor //tum islemler bitince kalan son primeFactor; en buyuk asal bolen olacaktır.
}

print(largestPrimeFactor(number: 600851475143))
